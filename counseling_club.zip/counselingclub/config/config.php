<?php


define('DB_HOST', 'localhost');
define('DB_NAME', 'smashonebadminton');
define('DB_USER', 'root');
define('DB_PASS', '');
